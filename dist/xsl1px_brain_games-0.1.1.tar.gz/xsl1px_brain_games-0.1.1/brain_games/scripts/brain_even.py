from brain_games.game import run


def main():
    run()
#def qwerty():
#    print('pizdec')


if __name__ == '__main__':
    main()